<?php
define('PATH', realpath('.'));
define('SUBFOLDER', false);
define('URL', 'https://smm.growworld.store' );
define('STYLESHEETS_URL', '//smm.growworld.store' );
date_default_timezone_set('Asia/Kolkata');

/*
 ini_set("display_errors","1");
error_reporting(E_ALL);   */

error_reporting(0);
return [
  'db' => [
    'name'    =>  'growworl_smm' ,
    'host'    =>  'localhost',
    'user'    =>  'growworl_smm' ,
    'pass'    =>  'growworl_smm' ,
    'charset' =>  'utf8mb4'
  ]
];

?>